<?php
function flavor_enqueue_scripts() {
    // CSS: tokens → base → components → theme → style.css
    // Roboto 已自托管在 base.css 的 @font-face 中
    wp_enqueue_style('flavor-tokens', FLAVOR_URI . '/assets/css/tokens.css', [], FLAVOR_VERSION);
    wp_enqueue_style('flavor-base', FLAVOR_URI . '/assets/css/base.css', ['flavor-tokens'], FLAVOR_VERSION);
    wp_enqueue_style('flavor-components', FLAVOR_URI . '/assets/css/components.css', ['flavor-tokens'], FLAVOR_VERSION);
    wp_enqueue_style('flavor-theme', FLAVOR_URI . '/assets/css/theme.css', ['flavor-base', 'flavor-components'], FLAVOR_VERSION);
    wp_enqueue_style('flavor-style', get_stylesheet_uri(), ['flavor-theme'], FLAVOR_VERSION);

    // JavaScript（全部 defer）
    wp_enqueue_script('flavor-color-engine', FLAVOR_URI . '/assets/js/color-engine.js', [], FLAVOR_VERSION, ['strategy' => 'defer', 'in_footer' => true]);
    wp_enqueue_script('flavor-theme-toggle', FLAVOR_URI . '/assets/js/theme-toggle.js', [], FLAVOR_VERSION, ['strategy' => 'defer', 'in_footer' => true]);
    wp_enqueue_script('flavor-ripple', FLAVOR_URI . '/assets/js/ripple.js', [], FLAVOR_VERSION, ['strategy' => 'defer', 'in_footer' => true]);
    wp_enqueue_script('flavor-navigation', FLAVOR_URI . '/assets/js/navigation.js', [], FLAVOR_VERSION, ['strategy' => 'defer', 'in_footer' => true]);
    wp_enqueue_script('flavor-search', FLAVOR_URI . '/assets/js/search.js', [], FLAVOR_VERSION, ['strategy' => 'defer', 'in_footer' => true]);

    // 种子色配置
    wp_localize_script('flavor-color-engine', 'flavorColorConfig', [
        'seedColor' => get_theme_mod('flavor_seed_color', '#6750A4'),
    ]);

    // 文章页加载 TOC
    if (is_single()) {
        wp_enqueue_script('flavor-toc', FLAVOR_URI . '/assets/js/toc.js', [], FLAVOR_VERSION, ['strategy' => 'defer', 'in_footer' => true]);
    }

    // 搜索数据
    wp_localize_script('flavor-search', 'flavorData', [
        'restUrl' => esc_url_raw(rest_url()),
        'nonce'   => wp_create_nonce('wp_rest'),
        'homeUrl' => home_url('/'),
    ]);

    // 评论回复
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'flavor_enqueue_scripts');

// 预加载自托管字体 + 异步加载 Noto Sans SC（中文增强）
function flavor_preload_assets() {
    // 预加载 Roboto（自托管）
    echo '<link rel="preload" href="' . FLAVOR_URI . '/assets/fonts/roboto-latin.woff2" as="font" type="font/woff2" crossorigin>' . "\n";
    // 异步加载 Noto Sans SC（中文字体太大，不自托管）
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
    echo '<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap">' . "\n";
    echo '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap" media="print" onload="this.media=\'all\'">' . "\n";
    echo '<noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap"></noscript>' . "\n";
}
add_action('wp_head', 'flavor_preload_assets', 1);

// 主题色初始化（防闪烁）+ 关键 CSS 内联
function flavor_inline_critical() {
    echo '<script>
    (function(){
        var t = localStorage.getItem("flavor-theme") || "auto";
        if (t === "auto") {
            t = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
        }
        document.documentElement.setAttribute("data-theme", t);
    })();
    </script>' . "\n";
}
add_action('wp_head', 'flavor_inline_critical', 0);
